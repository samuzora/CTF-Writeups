# What do?

You can use this to spin up your own container that runs pretty much identical
code to that which backs the challenge. You'll need to patch (& provide) the
python files ;)
